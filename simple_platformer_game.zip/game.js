
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const player = {
    x: 50, y: 300, width: 40, height: 40,
    color: "red", ySpeed: 0, xSpeed: 0,
    jumping: false
};

const gravity = 0.5;
const friction = 0.8;
const ground = 360;

const keys = {};

const platforms = [
    {x: 0, y: 360, width: 800, height: 40},
    {x: 200, y: 300, width: 120, height: 10},
    {x: 400, y: 250, width: 120, height: 10}
];

document.addEventListener("keydown", e => keys[e.key] = true);
document.addEventListener("keyup", e => keys[e.key] = false);

function update() {
    if (keys["ArrowRight"]) player.xSpeed = 5;
    else if (keys["ArrowLeft"]) player.xSpeed = -5;
    else player.xSpeed *= friction;

    if (keys[" "] && !player.jumping) {
        player.ySpeed = -10;
        player.jumping = true;
    }

    player.ySpeed += gravity;
    player.x += player.xSpeed;
    player.y += player.ySpeed;

    // Collision detection
    platforms.forEach(p => {
        if (player.x < p.x + p.width &&
            player.x + player.width > p.x &&
            player.y < p.y + p.height &&
            player.y + player.height > p.y) {
            player.y = p.y - player.height;
            player.ySpeed = 0;
            player.jumping = false;
        }
    });

    if (player.y + player.height > canvas.height) {
        player.y = canvas.height - player.height;
        player.ySpeed = 0;
        player.jumping = false;
    }
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw player
    ctx.fillStyle = player.color;
    ctx.fillRect(player.x, player.y, player.width, player.height);

    // Draw platforms
    ctx.fillStyle = "green";
    platforms.forEach(p => {
        ctx.fillRect(p.x, p.y, p.width, p.height);
    });
}

function loop() {
    update();
    draw();
    requestAnimationFrame(loop);
}

loop();
